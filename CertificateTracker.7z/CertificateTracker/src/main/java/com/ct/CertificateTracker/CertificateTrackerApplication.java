package com.ct.CertificateTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CertificateTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CertificateTrackerApplication.class, args);
	}

}
